USE penjualan;

SELECT * FROM transaksi_detail;